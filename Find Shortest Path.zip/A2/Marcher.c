/*
 * This is the file where all of your implementation goes.
 * You will be submitting (only) this file to MarkUs. The 
 * documentation for the functions here is a bit long (sorry!)
 * but I hope it's precise enough to not leave room for 
 * ambiguity in any of the edge cases.
 * 
 * Driver.c gives you a way to run this code on a single image,
 * and TestMarcher.c runs a few test cases to verify your solution.
 * Look at the relevant files for more information regarding how to
 * use them.
 *
 * CSCB63 Winter 2020 - Assignment 2
 * (c) Mustafa Quraish
 */

#include "Marcher.h"
typedef struct heap_struct{
  int pixel;
  int pre;
  double distance;
  int index_in_heap;
}Heap;
void insert_heap(Heap **array, int index, Heap *value, double distance){
  array[index] = value;
  value->distance =distance;
  // index_array[value->pixel]->index_in_heap = index;
  value->index_in_heap = index;
  while(index != 1){
    int parent = index/2;
    if(array[parent]->distance > value->distance){
      array[index] = array[parent];
      // index_array[array[parent]->pixel]->index_in_heap = index;
      array[parent]->index_in_heap = index;
      array[parent] = value;
      // index_array[value->pixel]->index_in_heap = parent;
      value->index_in_heap = parent;
    }else{
      break;
    }
    index = parent;
  }
}
int extract_min(Heap **array, int index){
  Heap *min = array[1];
  // index_array[min->pixel]->index_in_heap = -1;
  min->index_in_heap = -1;
  if(index != 1){
    array[1] = array[index];
    // index_array[array[index]->pixel]->index_in_heap = 1;
    array[index]->index_in_heap = 1;
  }
  int cur_index=1;
  while(cur_index <index){
    if(cur_index*2>=index){
      break;
    }else if(cur_index*2 == index-1){// only 1 child
      if(array[cur_index]->distance> array[cur_index*2]->distance){
        Heap *node =array[cur_index];
        array[cur_index] =  array[cur_index*2];
        // index_array[array[cur_index*2]->pixel]->index_in_heap = cur_index;
        array[cur_index*2]->index_in_heap = cur_index;
        array[cur_index*2] = node;
        // index_array[node->pixel]->index_in_heap = cur_index*2;
        node->index_in_heap = cur_index*2;
      }
      cur_index = cur_index*2;
    }else{
      int smaller;
      if(array[cur_index*2]->distance < array[cur_index*2+1]->distance){
        smaller = cur_index*2;
      }else{
        smaller = cur_index*2+1;
      }
      if(array[cur_index]->distance > array[smaller]->distance){
        Heap *node =array[cur_index];
        array[cur_index] =  array[smaller];
        // index_array[array[smaller]->pixel]->index_in_heap = cur_index;
        array[smaller]->index_in_heap = cur_index;
        array[smaller] = node;
        // index_array[node->pixel]->index_in_heap = smaller;
        node->index_in_heap = smaller;
      }
      cur_index = smaller;
    }
  }
  return min->pixel;

}
int change_piority(Heap **array, int index, double value){
  if(array[index]->distance > value){
    array[index]->distance = value;
    while(index != 1){
      int parent = index/2;
      if(array[parent]->distance > value){
        Heap *node = array[index];
        array[index] = array[parent];
        // index_array[array[parent]->pixel]->index_in_heap = index;
        array[parent]->index_in_heap = index;
        array[parent] = node;
        // index_array[node->pixel]->index_in_heap = parent;
        node->index_in_heap = parent;
      }else{
        break;
      }
      index = parent;
    }
    return -1;// changed piority
  }else{
    return -2;// didn't change
  }
}
int mux3to1(Heap **array, int *index, int option, double value, Heap *node){
  if(option == 1){//insert or change_piority
    if(node->index_in_heap == 0){
      (*(index)) ++;
      int indexcopy = *(index);
      insert_heap(array, indexcopy, node, value);
      return -3;// inserted into heap
    }else if(node->index_in_heap != -1){
      return change_piority(array, node->index_in_heap, value);
    }
  }else{// extract
    int indexcopy = *(index);
    int i = extract_min(array, indexcopy);
    (*(index))--;
    return i;
  }
  return -4;//this doing nothing, just want to ignore the warning
}
double findPath(struct image *mp, WeightFunc weight, int path[]) {
  /*
    Input: 
      im     - The image we are working on. For more information on what 
               this struct stores, look at ImgUtils.h
      
      weight - This is the weight **function**. You are supposed to use 
              this to find the energy required for each step by the Pixel 
              Marcher. The function takes in the 1-D coordinates of 2 pixels[*]
              and returns a double representing the cost to go from pixel a to 
              pixel b
                  usage: double cost = weight(im, a, b)

              [*] In memory, all the pixels are stored in a 1-D array (since 
                  memory is 1-D). Given a pixel with the coordinates (x,y), we
                  can compute it's 'pixel index' (an integer) as follows:
                      
                      int pixelIndex = x + y * (image width)
                                     = x + y * im->sx

                  For sake of not having to deal with tuples of (x,y) coordinates
                  (since this is hard in C), we will just deal with the index of 
                  a pixel from now on. If needed, you can extract the (x,y) coords
                  from the index as follows:
                          
                          x = pixelIndex % im->sx
                          y = pixelIndex / im->sx   (integer division)

                  In general, the energy needed to go from pixel a->b is not the same
                  as the energy needed to go from pixel b->a.

                  ** The cost must always be non-negative. **

    Requirements: 
        Your objective is to find the least-energy path from pixel (0,0) to pixel
        (sx-1, sy-1), along with the amount of energy required to traverse this path. 
        Here, sx and sy are the x and y dimensions of the image. (These are stored in 'im')

        From each pixel, it is possible to step to at most 4 other pixels, namely the ones 
        on it's top, right, bottom and left. All of these steps may require different amounts 
        of energy, and you have to use the given weight function to compute these.
        
                                                    (x, y-1)
                                                        ^
                                                        |
                                    (x-1, y) <------ (x, y) ------> (x+1, y)
                                                        |
                                                        v
                                                    (x, y+1)

        * You might want to figure out what the neighbours would be purely using the index 
        * of the pixel. This is not necessary but may help simplify your code.

        You should store the resulting least-energy path in the array `path`, such that
                - path[0] = start location = index of (0,0)        =  0 +  0 * sx = 0   from [*]
                - path[i] = the i-th node along the shortest path.
                - path[L-1] = end location = index of (sx-1, sy-1) = sx + sy * sx       from [*]
                - path[L] = -1   // To mark the end of the path
        where `L` is the number of nodes in your shortest path. Any valid shortest path is fine.
        You may assume there is already a valid amount of space allocated for the `path` array.
        
        The return value of the function is a double, which represents the total energy required
        to traverse along the shortest energy path. This value must be unique, even if there are
        multiple corresponding shortest paths.
            
      Each test case in the ones provided shouldn't take more than 1 second on the lab machines 
      in BV473. This will only really happen if your implementation is *really* inefficient, 
      which should not be the case for pretty much anyone (one of the benefits of using C! last
      year, some solutions took up to a few minutes for the bigmaze.ppm).
   */
  int pixels = mp->sx * mp->sy;
  Heap *heap_array[pixels];
  Heap *pixel_array[pixels];
  int heap_size=0;

  for(int i=0; i<pixels; i++){
    pixel_array[i] = malloc(sizeof(Heap));
    pixel_array[i]->pixel = i;
    pixel_array[i]->pre = -1;
    pixel_array[i]->distance = 99999;
    pixel_array[i]->index_in_heap = 0;
  }
  pixel_array[0]->index_in_heap = -1;
  pixel_array[0]->distance = 0;
  pixel_array[0]->pre = -1;
  int cur_pixel = 0;
  while(cur_pixel != pixels-1){
    if(cur_pixel % mp->sx != 0){// check if pixel in the leftmost row
      double distance = pixel_array[cur_pixel]->distance + weight(mp, cur_pixel, cur_pixel-1);
      int result = mux3to1(heap_array, &heap_size, 1, distance, pixel_array[cur_pixel-1]);
      if(result == -1 || result == -3){
        pixel_array[cur_pixel-1]->pre = cur_pixel;
      }
    }
    if(cur_pixel % mp->sx != mp->sx-1){// check if pixel in the rightmost row
      double distance = pixel_array[cur_pixel]->distance + weight(mp, cur_pixel, cur_pixel+1);
      int result = mux3to1(heap_array, &heap_size, 1, distance, pixel_array[cur_pixel+1]);
      if(result == -1 || result == -3){
        pixel_array[cur_pixel+1]->pre = cur_pixel;
      }
    }
    if(cur_pixel / mp->sx != 0){// check if pixel in the top column
      double distance = pixel_array[cur_pixel]->distance + weight(mp, cur_pixel, cur_pixel - mp->sx);
      int result = mux3to1(heap_array, &heap_size, 1, distance, pixel_array[cur_pixel - mp->sx]);
      if(result == -1 || result == -3){
        pixel_array[cur_pixel - mp->sx]->pre = cur_pixel;
      }
    }
    if(cur_pixel / mp->sx != mp->sy-1){// check if pixel in the bottom column
      double distance = pixel_array[cur_pixel]->distance + weight(mp, cur_pixel, cur_pixel + mp->sx);
      int result = mux3to1(heap_array, &heap_size, 1, distance, pixel_array[cur_pixel + mp->sx]);
      if(result == -1 || result == -3){
        pixel_array[cur_pixel + mp->sx]->pre = cur_pixel;
      }
    }
    cur_pixel = mux3to1(heap_array, &heap_size, 2,0,NULL);
  }
  int length=0;
  double cost = pixel_array[cur_pixel]->distance;
  while(cur_pixel != -1){
    length++;
    cur_pixel = pixel_array[cur_pixel]->pre;
  }
  path[length] = -1;
  length--;
  cur_pixel = pixels-1;
  while(length >= 0){
    path[length] = cur_pixel;
    cur_pixel = pixel_array[cur_pixel]->pre;
    length--;
  }
  return cost;       // Replace with cost pf shortest path      
}

double allColourWeight(Image *im, int a, int b) {
  /*
     Input:
        im     - The image we are working on. For more information on what 
                 this struct stores, look at ImgUtils.h
        a, b   - Two (arbitrary, and valid) pixel 'indices' (look above, [*]),
                  where you want to return the weight from pixel a to pixel b

     Requirements:

        Define your own weight function here so that when "25colours.ppm" is run with 
        this function, the least-energy path in the image satisfies the following 
        constraints:

            (1) The least energy path must visit every one of the 25 colours in the image. 
                The order in which the path visits these colours does *not* matter, as 
                long as it visits them all. Be careful - missing even one colour will 
                result in 0 for this function.

            (2) The path can stay on one colour for as many steps as necessary, however 
                once the path leaves a colour, it can NEVER go through another pixel of 
                the same colour again. (Said in another way, it can only enter/exit each 
                coloured box once)

            (3) For any two given pixels, the energy required to step between them 
                 *must* be non-negative. If you have negative energies, this function 
                 may not work as intended.

        There is no restriction on path length, it can be as long or as short as needed - as 
        long as it satisfies the conditions above. Also, the amount of energy to step from 'a' 
        to 'b' does not have to be the same as the energy to step from 'b' to 'a'. This 
        is left up to you.

        Important Note: This weight function will NOT be tested with your solution to the first 
                        part of the question. This will be passed into my code and should still 
                        produce the results as above, so do not try to change your findPath() 
                        method to help with this.

                        This function will be tested ONLY on the specified image, so you do not 
                        have to worry about generalizing it. Just make sure that it does not 
                        depend on anything else in your code other than the arguments passed in.


        How to test:    Use the result of outputPath() to (visually) help you debug. Displaying
                        the path will be useful to start, as it will give you a general idea of 
                        what the least-energy path looks like.
   */
  
  return 0; // Default return value
}
